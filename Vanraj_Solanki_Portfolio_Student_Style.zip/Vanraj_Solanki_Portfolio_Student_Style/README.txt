VANRAJ SOLANKI PORTFOLIO — SIMPLE STUDENT VERSION

Files:
- index.html
- style.css

How to open:
1. Extract this ZIP.
2. Open index.html in Chrome.
3. Replace your-email@example.com with your own email.
4. To add your own photo, replace the VS initials area in index.html with an img tag and add your photo file.

The design intentionally uses a simple student portfolio style, with editable text and no complex frameworks.
